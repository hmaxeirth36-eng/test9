package com.water.module.modules.donut;

import com.water.module.Category;
import com.water.module.Module;
import com.water.module.setting.Setting;
import com.water.render.FontRenderer;
import com.water.render.ProjectedPoint;
import com.water.render.Render3D;
import com.water.render.RenderUtils;
import com.water.render.ShapeBatch;
import java.awt.Color;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.Camera;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.opengl.GL11;

/**
 * Highlights chunks that contain other players below Max Y (default -1).
 */
public final class PlayerDebug extends Module {
   public static PlayerDebug INSTANCE;

   public final Setting<Integer> maxY = new Setting<>("Max Y", -1, -64, 320);
   public final Setting<Color> fillColor = new Setting<>("Fill Color", new Color(40, 255, 80, 50));
   public final Setting<Integer> fillAlpha = new Setting<>("Fill Alpha", 50, 0, 255);
   public final Setting<Boolean> showInfo = new Setting<>("Show Name", true);
   public final Setting<Boolean> showOutline = new Setting<>("Outline", true);

   public static final class Hit {
      public final String name;
      public final double y;

      public Hit(String name, double y) {
         this.name = name;
         this.y = y;
      }
   }

   public final Map<ChunkPos, Hit> hits = new ConcurrentHashMap<>();
   private final ProjectedPoint projected = new ProjectedPoint();

   public PlayerDebug() {
      super("Player Debug", Category.DONUT);
      INSTANCE = this;
      this.addSetting(this.maxY);
      this.addSetting(this.fillColor);
      this.addSetting(this.fillAlpha);
      this.addSetting(this.showInfo);
      this.addSetting(this.showOutline);
   }

   @Override
   public void onTick() {
      if (mc.world == null || mc.player == null) {
         this.hits.clear();
         return;
      }

      Map<ChunkPos, Hit> next = new ConcurrentHashMap<>();
      int limitY = this.maxY.getValue();

      for (AbstractClientPlayerEntity player : mc.world.getPlayers()) {
         if (player == mc.player) continue;
         if (player.getY() > limitY) continue;
         ChunkPos cp = player.getChunkPos();
         String name = player.getName().getString();
         // if multiple players in same chunk, keep the one with lowest Y
         Hit existing = next.get(cp);
         if (existing == null || player.getY() < existing.y) {
            next.put(cp, new Hit(name, player.getY()));
         }
      }
      this.hits.clear();
      this.hits.putAll(next);
   }

   @Override
   public void onRender(MatrixStack matrices, float tickDelta) {
      if (mc.world == null || mc.player == null || this.hits.isEmpty()) return;

      Camera camera = RenderUtils.getCamera();
      if (camera == null) return;
      Vec3d cam = RenderUtils.getCameraPos(camera);

      int limitY = this.maxY.getValue();
      double y1 = mc.world.getBottomY() - cam.y;
      double y2 = limitY + 1.0 - cam.y;

      Color base = this.fillColor.getValue();
      Color fill = new Color(base.getRed(), base.getGreen(), base.getBlue(), this.fillAlpha.getValue());
      Color outline = new Color(base.getRed(), base.getGreen(), base.getBlue(), Math.min(255, this.fillAlpha.getValue() + 120));

      matrices.push();
      GL11.glDisable(GL11.GL_DEPTH_TEST);
      ShapeBatch batch = RenderUtils.beginShapeBatch(matrices);

      for (ChunkPos cp : this.hits.keySet()) {
         double x1 = (cp.x << 4) - cam.x;
         double z1 = (cp.z << 4) - cam.z;
         batch.renderFilledBox(x1, y1, z1, x1 + 16.0, y2, z1 + 16.0, fill);
         if (this.showOutline.getValue()) {
            batch.renderOutlineBox(x1, y1, z1, x1 + 16.0, y2, z1 + 16.0, outline);
         }
      }

      batch.flush();
      GL11.glEnable(GL11.GL_DEPTH_TEST);
      matrices.pop();
   }

   public static void renderHud(DrawContext context, float tickDelta) {
      PlayerDebug self = INSTANCE;
      if (self == null || !self.isEnabled() || !self.showInfo.getValue()) return;
      if (self.hits.isEmpty()) return;

      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc == null || mc.player == null || mc.world == null) return;

      double textY = self.maxY.getValue() + 2.5;

      for (Map.Entry<ChunkPos, Hit> e : self.hits.entrySet()) {
         ChunkPos cp = e.getKey();
         Hit hit = e.getValue();
         double worldX = (cp.x << 4) + 8.0;
         double worldZ = (cp.z << 4) + 8.0;

         if (!Render3D.projectToPoint(Render3D.modelViewMatrix, Render3D.projectionMatrix, worldX, textY, worldZ, self.projected)) {
            continue;
         }
         if (!self.projected.visible) continue;

         String line1 = "\u265F " + hit.name; // pawn symbol = player marker
         String line2 = "Y " + (int) hit.y;

         float x = (float) self.projected.x;
         float y = (float) self.projected.y;

         int w1 = FontRenderer.INSTANCE.getWidth(line1);
         int w2 = FontRenderer.INSTANCE.getWidth(line2);

         FontRenderer.INSTANCE.drawString(context, line1, x - w1 / 2f + 1, y + 1, 0xFF000000);
         FontRenderer.INSTANCE.drawString(context, line1, x - w1 / 2f, y, 0xFF55FF55);
         FontRenderer.INSTANCE.drawString(context, line2, x - w2 / 2f + 1, y + 11, 0xFF000000);
         FontRenderer.INSTANCE.drawString(context, line2, x - w2 / 2f, y + 10, 0xFFFFFFFF);
      }
   }
}
